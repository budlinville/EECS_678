var NAVTREE =
[
  [ "EECS678: Project 2: Scheduler", "index.html", [
    [ "EECS 678: Project 2: Scheduler", "index.html", null ],
    [ "Doxygen", "doxygen.html", null ],
    [ "Compare Function", "comparer-page.html", null ],
    [ "Examples", "examplesPage.html", "examplesPage" ],
    [ "acknowledgement", "acknowledgement.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Enumerations", "globals_enum.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"acknowledgement.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';