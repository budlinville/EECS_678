var dir_95e02ef04a311c062bdfd8bc0e155e51 =
[
    [ "libpriqueue.c", "libpriqueue_8c.html", "libpriqueue_8c" ],
    [ "libpriqueue.h", "libpriqueue_8h.html", "libpriqueue_8h" ]
];