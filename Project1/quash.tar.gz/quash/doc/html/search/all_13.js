var searchData=
[
  ['update_5fand_5fdestroy_5fback_5fexample',['update_and_destroy_back_Example',['../deque_8h.html#ad3f94c060781ace2b457bb5152956f89',1,'deque.h']]],
  ['update_5fand_5fdestroy_5ffront_5fexample',['update_and_destroy_front_Example',['../deque_8h.html#adf8146c22426a01c64c5de4c7f751575',1,'deque.h']]],
  ['update_5fback_5fexample',['update_back_Example',['../deque_8h.html#a0705ac52e0952213b9f1ce7f80bf977e',1,'deque.h']]],
  ['update_5ffront_5fexample',['update_front_Example',['../deque_8h.html#a2f5457e6575eb38d59b7504770ca247e',1,'deque.h']]]
];
