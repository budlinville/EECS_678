var searchData=
[
  ['generic',['generic',['../unionCommand.html#a22a7dad0e3935c261a1643c8c5ea46aa',1,'Command']]]
];
