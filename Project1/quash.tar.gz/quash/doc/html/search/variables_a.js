var searchData=
[
  ['next',['next',['../structMemoryPool.html#af5fd87a1dc44d4e5ea496d403c426d92',1,'MemoryPool']]]
];
